# SADEE X DIMA — ONE PACKAGE

This single repository contains both projects:

- `gaming-app/` → Android Gaming Performance Optimizer
- `admin-panel/` → Separate web Admin Panel

## GitHub Actions

The included workflow:

1. Builds the Android APK.
2. Uploads the APK as an Actions artifact.
3. Deploys the separate admin panel to GitHub Pages.

Workflow file:
`.github/workflows/build-all.yml`

## Important

The Android app and Admin Panel remain separate projects inside the same repository. They can share the same Supabase backend.

For GitHub Pages, enable:
Settings → Pages → Source → GitHub Actions

For Supabase, configure the public URL/anon key in the admin panel and use proper RLS policies. Never put a Supabase service-role key in the Android app or browser.
