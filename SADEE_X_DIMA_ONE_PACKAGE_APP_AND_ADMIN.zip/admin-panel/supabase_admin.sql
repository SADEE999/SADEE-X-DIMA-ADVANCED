create extension if not exists pgcrypto;
create table if not exists public.license_keys(id uuid primary key default gen_random_uuid(),license_key text unique not null,username text,plan text default '7',status text default 'active',expires_at timestamptz,device_limit int default 1,device_count int default 0,created_at timestamptz default now(),updated_at timestamptz default now());
create table if not exists public.license_devices(id uuid primary key default gen_random_uuid(),license_key_id uuid references public.license_keys(id) on delete cascade,device_id text not null,device_name text,android_version text,ram text,storage text,cpu text,first_activated_at timestamptz default now(),last_active_at timestamptz default now(),unique(license_key_id,device_id));
create table if not exists public.game_profiles(id uuid primary key default gen_random_uuid(),game_name text unique not null,enabled boolean default true,performance_mode text default 'high',settings jsonb default '{}'::jsonb);
create table if not exists public.optimizer_settings(id uuid primary key default gen_random_uuid(),key text unique not null,value jsonb default '{}'::jsonb);
create table if not exists public.app_updates(id uuid primary key default gen_random_uuid(),version text not null,apk_url text,message text,force_update boolean default false,active boolean default true,created_at timestamptz default now());
create table if not exists public.app_settings(id uuid primary key default gen_random_uuid(),app_name text default 'SADEE X DIMA',whatsapp text default '+94 76 847 2404',whatsapp_group text,tiktok text,price_7d numeric default 500,price_1m numeric default 1000,price_lifetime numeric default 2200,announcement text,maintenance boolean default false,updated_at timestamptz default now());
alter table public.license_keys enable row level security;
alter table public.license_devices enable row level security;
alter table public.game_profiles enable row level security;
alter table public.optimizer_settings enable row level security;
alter table public.app_updates enable row level security;
alter table public.app_settings enable row level security;
-- Add admin-only RLS policies using your Supabase admin UID before production.
