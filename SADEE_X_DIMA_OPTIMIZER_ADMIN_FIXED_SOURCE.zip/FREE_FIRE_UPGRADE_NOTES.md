# SADEE X DIMA PRO — Free Fire source upgrade

## Changes
- Focused the Boost screen on Free Fire.
- Added a saved preparation profile (Battery Saver / Balanced / Performance Prep).
- Added a readiness check using Android-reported battery level, battery temperature where available, storage usage, and RAM summary.
- Added a direct Free Fire launch action.
- Clarified that cache cleanup affects this app only and that Android controls CPU/GPU clocks.
- Removed claims that the button itself boosts FPS or optimizes other apps.

## Important limits
This is an updated Android source project, not a verified APK. No APK was built or installed in this environment. The readiness card is not an FPS benchmark, and performance improvements must be measured on the target phone. The app cannot force Free Fire's FPS, GPU clocks, or thermal limits without privileged/system-level access.

## Build
Open `sadee_src/gaming-app` in Android Studio and build the `app` module. Test on the target phone, verify that Free Fire launches, and compare in-game FPS/temperature before and after under the same conditions.
