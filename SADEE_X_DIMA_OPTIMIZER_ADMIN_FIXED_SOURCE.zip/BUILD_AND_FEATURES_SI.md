# SADEE X DIMA — Updated Source Package

## Included
- `gaming-app/`: Android gaming optimizer app source.
- `admin-app/`: standalone Android admin panel app source.
- `admin-panel/`: web admin panel source and SQL migrations.
- `.github/workflows/build-all.yml`: builds both APKs in GitHub Actions and uploads them as one artifact.

## Build with GitHub Actions
1. Extract this ZIP and upload its contents to the root of a GitHub repository (the folders `gaming-app`, `admin-app`, and `.github` must be at repository root).
2. Open **Actions** → **SADEE X DIMA - Build Both APKs** → **Run workflow**.
3. Download the `SADEE-X-DIMA-APKs` artifact. It contains both the optimizer APK and standalone admin APK.

## Admin panel in optimizer
On app pages with the header, tap the top-right `⋮` menu and choose **Admin Panel**. It opens the bundled admin panel in an in-app dialog; the close button dismisses the panel rather than closing the entire app.

## Optimizer behavior
`FULL OPTIMIZER AND LAUNCH` performs actual supported steps: reads battery/temperature/storage/RAM readiness, requests memory trimming for this app, clears this app's own temporary cache, then opens game selection. Select a supported installed game to launch it. Android does not allow an ordinary app to forcibly clear another game's private cache or force CPU/GPU clocks on all devices, so the UI does not claim those unsupported actions.

## Backend note
The admin web panel requires internet access and the configured Supabase project. Review and apply the SQL migrations in `admin-panel/` in Supabase as appropriate. The bundled admin UI is a no-login build; do not publish it publicly until proper server-side admin authentication and database Row Level Security policies are configured.
