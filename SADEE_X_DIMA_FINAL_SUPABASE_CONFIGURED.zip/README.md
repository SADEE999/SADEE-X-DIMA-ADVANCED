# SADEE X DIMA - ONE PACKAGE

Contains three deliverables:
- `gaming-app/` — SADEE X DIMA Gaming Performance Optimizer Android app.
- `admin-app/` — Android app version of the Admin Panel, opening directly without the old email/password gate.
- `admin-panel/` — Web Admin Panel, also opening directly without the old login gate.

Both apps use the generated SADEE X DIMA neon logo.

Current license prices:
- 7 Days — Rs. 500
- 1 Month — Rs. 1,000
- Lifetime — Rs. 2,200

The Android workflow builds both APKs and deploys the web Admin Panel to GitHub Pages.
