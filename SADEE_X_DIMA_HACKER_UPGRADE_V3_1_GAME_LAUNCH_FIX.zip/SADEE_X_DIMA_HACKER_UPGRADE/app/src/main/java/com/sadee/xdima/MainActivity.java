package com.sadee.xdima;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Environment;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String PREF = "sadee_session";
    private static final String KEY_LOGGED = "logged_in";

    private final int BG = Color.rgb(3, 7, 5);
    private final int CARD = Color.rgb(8, 15, 11);
    private final int GREEN = Color.rgb(0, 255, 102);
    private final int RED = Color.rgb(255, 23, 68);
    private final int WHITE = Color.WHITE;
    private final int MUTED = Color.rgb(155, 185, 170);

    private LinearLayout root;
    private LinearLayout content;
    private TextView pageTitle;
    private int currentPage = 1;
    private boolean loggedIn = false;
    private boolean premium = false;
    private int performance = 30;
    private final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(3,7,5));
        w.setNavigationBarColor(Color.rgb(3,7,5));

        SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
        loggedIn = sp.getBoolean(KEY_LOGGED, false);

        if (loggedIn) {
            showApp();
        } else {
            showLogin();
        }
    }

    private GradientDrawable bg(int color, float radius, int strokeColor, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        if (stroke > 0) g.setStroke(stroke, strokeColor);
        return g;
    }

    private TextView text(String s, float size, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextColor(color);
        v.setTextSize(size);
        v.setTypeface(Typeface.MONOSPACE);
        v.setPadding(14, 10, 14, 10);
        return v;
    }

    private TextView label(String s) {
        TextView v = text(s, 10, MUTED);
        v.setLetterSpacing(0.12f);
        return v;
    }

    private Button action(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.BLACK);
        b.setTextSize(12);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(12, 6, 12, 6);
        b.setBackground(bg(color, 18, color, 1));
        return b;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(14, 14, 14, 14);
        c.setBackground(bg(CARD, 20, Color.rgb(20, 55, 35), 1));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, 12);
        c.setLayoutParams(p);
        return c;
    }

    private LinearLayout rgbCard(int accent) {
        LinearLayout c = card();
        c.setPadding(16, 16, 16, 16);
        c.setBackground(bg(Color.rgb(5, 10, 7), 22, accent, 2));
        return c;
    }

    private void rgbPulse(final View v, final int[] colors) {
        if (v == null || colors == null || colors.length == 0) return;
        final int[] index = {0};
        handler.post(new Runnable() {
            @Override public void run() {
                if (v.getBackground() instanceof GradientDrawable) {
                    ((GradientDrawable) v.getBackground()).setStroke(2, colors[index[0] % colors.length]);
                }
                index[0]++;
                handler.postDelayed(this, 700);
            }
        });
    }

    private void add(LinearLayout parent, View child) {
        parent.addView(child, new LinearLayout.LayoutParams(-1, -2));
    }

    private void showLogin() {
        loggedIn = false;
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(22, 24, 22, 24);
        root.setBackgroundColor(BG);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.sadee.xdima.R.drawable.sadee_logo);
        logo.setPadding(4, 4, 4, 4);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(118, 118);
        lpLogo.gravity = Gravity.CENTER;
        root.addView(logo, lpLogo);

        TextView title = text("SADEE X DIMA SENSI", 27, GREEN);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        root.addView(title);

        TextView anim = text("[ SYSTEM BOOTING ]", 10, RED);
        anim.setGravity(Gravity.CENTER);
        anim.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        root.addView(anim);

        TextView sub = text("SENSITIVITY // CYBER PERFORMANCE SYSTEM", 9, MUTED);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        TextView line = text("━━━━━━━━━━━━━━━━━━━━━━━━", 10, RED);
        line.setGravity(Gravity.CENTER);
        root.addView(line);

        // Login intro animation: pulse + scan/glitch style text.
        logo.setAlpha(0.45f);
        logo.setScaleX(0.82f);
        logo.setScaleY(0.82f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(850).start();
        title.setAlpha(0f);
        title.setTranslationY(16f);
        title.animate().alpha(1f).translationY(0f).setStartDelay(300).setDuration(650).start();
        final String[] boot = {"[ SYSTEM BOOTING ]", "[ SENSI ENGINE ONLINE ]", "[ RGB CORE READY ]", "[ SECURE ACCESS ]"};
        handler.post(new Runnable() {
            int i = 0;
            @Override public void run() {
                anim.setText(boot[i % boot.length]);
                anim.setTextColor((i % 2 == 0) ? RED : GREEN);
                i++;
                if (root != null && root.getParent() == null) {
                    handler.postDelayed(this, 650);
                }
            }
        });

        LinearLayout box = rgbCard(GREEN);
        TextView access = text("SECURE ACCESS", 14, WHITE);
        access.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        box.addView(access);

        EditText key = new EditText(this);
        key.setHint("ENTER ACTIVATION KEY");
        key.setHintTextColor(Color.rgb(80,105,90));
        key.setTextColor(WHITE);
        key.setSingleLine(true);
        key.setInputType(0x00000081);
        key.setBackground(bg(Color.rgb(4,9,6), 14, Color.rgb(30,80,50), 1));
        key.setPadding(16, 4, 16, 4);
        box.addView(key, new LinearLayout.LayoutParams(-1, 58));

        Button login = action("⚡  UNLOCK SYSTEM", GREEN);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, 52);
        blp.setMargins(0, 12, 0, 0);
        box.addView(login, blp);

        TextView info = text(
                "FREE KEY : FREE01\n" +
                "FREE PERFORMANCE : 30%\n" +
                "PREMIUM PERFORMANCE : 90% / 100%\n\n" +
                "UPGRADE → WhatsApp",
                10, MUTED);
        box.addView(info);

        Button buy = action("☠  BUY / UPGRADE", RED);
        box.addView(buy, new LinearLayout.LayoutParams(-1, 52));

        root.addView(box, new LinearLayout.LayoutParams(-1, -2));
        rgbPulse(box, new int[]{GREEN, RED, Color.rgb(0, 220, 255), Color.rgb(170, 0, 255)});
        TextView foot = text("SADEE X DIMA OPTIMIZER  •  V2.0", 9, Color.rgb(80,105,90));
        foot.setGravity(Gravity.CENTER);
        root.addView(foot);

        setContentView(root);

        View.OnClickListener loginClick = v -> {
            String entered = key.getText().toString().trim();
            if ("FREE01".equalsIgnoreCase(entered)) {
                loggedIn = true;
                premium = false;
                performance = 30;
                getSharedPreferences(PREF, MODE_PRIVATE).edit()
                        .putBoolean(KEY_LOGGED, true)
                        .apply();
                showApp();
            } else {
                key.setText("");
                Toast.makeText(this, "ACCESS DENIED • INVALID KEY", Toast.LENGTH_SHORT).show();
            }
        };
        login.setOnClickListener(loginClick);
        key.setOnEditorActionListener((v, actionId, event) -> {
            loginClick.onClick(login);
            return true;
        });
        buy.setOnClickListener(v -> openWhatsApp(
                "Hello SADEE, I want to upgrade SADEE X DIMA OPTIMIZER.\n\n" +
                "Plans:\n7 Days - RS.500\n1 Month - RS.1000\nLifetime - RS.2200"));
    }

    private void showApp() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(12, 8, 12, 6);
        header.setBackground(bg(Color.rgb(5,10,7), 0, Color.rgb(18,60,34), 1));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.sadee_logo);
        header.addView(logo, new LinearLayout.LayoutParams(48,48));

        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        TextView h1 = text("SADEE X DIMA", 16, GREEN);
        h1.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        TextView h2 = text("OPTIMIZER // ONLINE", 8, MUTED);
        ht.addView(h1);
        ht.addView(h2);
        header.addView(ht, new LinearLayout.LayoutParams(0,-2,1));

        TextView pct = text((premium ? "100%" : "30%"), 13, premium ? GREEN : RED);
        pct.setGravity(Gravity.CENTER);
        header.addView(pct, new LinearLayout.LayoutParams(58,48));

        root.addView(header);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(12, 12, 12, 8);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(4, 4, 4, 4);
        nav.setBackgroundColor(Color.rgb(5,10,7));

        String[] navs = {"⌂\nHOME","⚡\nBOOST","◉\nMONITOR","$ \nUPGRADE","⚙\nSETTINGS"};
        for (int i=0;i<5;i++) {
            final int page = i+1;
            Button b = action(navs[i], page == currentPage ? GREEN : Color.rgb(25,45,32));
            b.setTextColor(page == currentPage ? Color.BLACK : WHITE);
            nav.addView(b, new LinearLayout.LayoutParams(0,62,1));
            b.setOnClickListener(v -> page(page));
        }
        root.addView(nav);

        setContentView(root);
        page(currentPage);
    }

    private void page(int n) {
        currentPage = n;
        content.removeAllViews();

        if (n == 1) homePage();
        if (n == 2) boostPage();
        if (n == 3) monitorPage();
        if (n == 4) upgradePage();
        if (n == 5) settingsPage();
    }

    private void pageHeader(String title, String sub) {
        pageTitle = text(title, 22, GREEN);
        pageTitle.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        content.addView(pageTitle);
        content.addView(text(sub, 9, MUTED));
        content.addView(text("━━━━━━━━━━━━━━━━━━━━━━━━", 9, RED));
    }

    private void homePage() {
        pageHeader("COMMAND CENTER", "REAL DEVICE DATA • RGB CYBER INTERFACE • LOCAL OPTIMIZER");

        LinearLayout status = rgbCard(GREEN);
        status.addView(text("SYSTEM STATUS", 10, MUTED));
        TextView online = text("●  ONLINE / READY", 18, GREEN);
        online.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        status.addView(online);
        status.addView(text("ACCESS : " + (premium ? "PREMIUM" : "FREE01"), 11, WHITE));
        status.addView(text("PERFORMANCE TIER : " + performance + "%", 12, premium ? GREEN : RED));
        content.addView(status);
        rgbPulse(status, new int[]{GREEN, Color.rgb(0, 220, 255), RED});

        LinearLayout device = rgbCard(Color.rgb(0, 220, 255));
        TextView dh = text("DEVICE INTELLIGENCE", 16, WHITE);
        dh.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        device.addView(dh);
        device.addView(text("━━━━━━━━━━━━━━━━━━━━", 9, RED));

        String[] details = {
                "DEVICE", Build.MANUFACTURER + " " + Build.MODEL,
                "ANDROID", Build.VERSION.RELEASE + "  •  API " + Build.VERSION.SDK_INT,
                "CPU / HARDWARE", Build.HARDWARE,
                "CPU ABI", Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "UNKNOWN",
                "BATTERY", batteryText(),
                "PROFILE", (premium ? "MAX CYBER" : "FREE CORE") + "  •  " + performance + "%"
        };
        for (int i = 0; i < details.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(12, 9, 12, 9);
            int accent = (i / 2 % 2 == 0) ? GREEN : RED;
            row.setBackground(bg(Color.rgb(7, 14, 10), 16, accent, 1));
            TextView l = text(details[i], 9, MUTED);
            l.setLetterSpacing(0.12f);
            TextView val = text(details[i + 1], 15, WHITE);
            val.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            row.addView(l);
            row.addView(val);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.setMargins(0, 0, 0, 8);
            device.addView(row, rp);
        }
        content.addView(device);
        rgbPulse(device, new int[]{Color.rgb(0, 220, 255), GREEN, RED, Color.rgb(170, 0, 255)});

        LinearLayout quick = rgbCard(RED);
        quick.addView(text("QUICK ACTIONS", 15, WHITE));
        Button b = action("⚡  START OPTIMIZER", GREEN);
        quick.addView(b, new LinearLayout.LayoutParams(-1, 54));
        b.setOnClickListener(v -> runBoost());
        Button up = action("☠  UNLOCK 90% / 100%", RED);
        quick.addView(up, new LinearLayout.LayoutParams(-1, 54));
        up.setOnClickListener(v -> page(4));
        content.addView(quick);
        rgbPulse(quick, new int[]{RED, Color.rgb(255, 120, 0), GREEN, Color.rgb(0, 220, 255)});

        content.addView(text("DEVICE VALUES ARE READ LOCALLY FROM ANDROID. PERFORMANCE % IS AN APP PROFILE TIER.", 9, Color.rgb(105,130,115)));
    }

    private void boostPage() {
        pageHeader("BOOST ENGINE", "SCAN → ANALYZE → APPLY APP-OWNED PROFILE");

        LinearLayout meter = card();
        TextView state = text("READY TO START", 16, GREEN);
        state.setGravity(Gravity.CENTER);
        meter.addView(state);

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        meter.addView(progress, new LinearLayout.LayoutParams(-1,18));
        TextView result = text("PROFILE: " + performance + "%\nCPU: " + Build.HARDWARE + "\nMODE: " + (premium ? "MAX" : "FREE"), 10, MUTED);
        meter.addView(result);

        Button start = action("⚡  RUN 10s BOOST", GREEN);
        meter.addView(start, new LinearLayout.LayoutParams(-1,54));
        start.setOnClickListener(v -> {
            start.setEnabled(false);
            state.setText("SCANNING...");
            progress.setProgress(0);
            final int[] p = {0};
            Runnable r = new Runnable() {
                @Override public void run() {
                    p[0] += 10;
                    progress.setProgress(p[0]);
                    if (p[0] < 100) {
                        state.setText(p[0] < 50 ? "ANALYZING DEVICE..." : "APPLYING PROFILE...");
                        handler.postDelayed(this, 1000);
                    } else {
                        state.setText("OPTIMIZED • READY");
                        result.setText("CONNECTION : STABLE\nDEVICE : " + Build.MANUFACTURER.toUpperCase(Locale.US) + " " + Build.MODEL.toUpperCase(Locale.US) +
                                "\nGAME : FREE FIRE\nPROFILE : " + (premium ? "MAX" : "FREE") +
                                "\nPERFORMANCE TIER : " + performance + "%\nSTATUS : SADEE X DIMA OPTIMIZED");
                        start.setEnabled(true);
                    }
                }
            };
            handler.post(r);
        });
        content.addView(meter);

        LinearLayout tools = card();
        tools.addView(text("TOOLS", 13, WHITE));
        String[] items = {"RAM SCAN", "CACHE CHECK", "NETWORK CHECK", "BATTERY CHECK", "STORAGE CHECK"};
        for (String item : items) {
            TextView x = text("✓  " + item + "     READY", 10, GREEN);
            tools.addView(x);
        }
        content.addView(tools);
    }

    private void monitorPage() {
        pageHeader("LIVE MONITOR", "REAL ANDROID / DEVICE VALUES");

        LinearLayout c = card();
        c.addView(text("DEVICE", 12, GREEN));
        c.addView(text(deviceInfo(), 10, WHITE));
        content.addView(c);

        LinearLayout m = card();
        m.addView(text("MONITOR", 12, GREEN));
        m.addView(text("BATTERY : " + batteryText(), 11, WHITE));
        m.addView(text("ANDROID : " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")", 11, WHITE));
        m.addView(text("MANUFACTURER : " + Build.MANUFACTURER, 11, WHITE));
        m.addView(text("MODEL : " + Build.MODEL, 11, WHITE));
        m.addView(text("HARDWARE : " + Build.HARDWARE, 11, WHITE));
        m.addView(text("PERFORMANCE PROFILE : " + performance + "%", 11, premium ? GREEN : RED));
        content.addView(m);

        Button refresh = action("↻  REFRESH LIVE DATA", GREEN);
        content.addView(refresh, new LinearLayout.LayoutParams(-1,52));
        refresh.setOnClickListener(v -> {
            page(3);
            Toast.makeText(this, "LIVE DATA REFRESHED", Toast.LENGTH_SHORT).show();
        });
    }

    private void upgradePage() {
        pageHeader("UPGRADE CENTER", "UNLOCK PREMIUM PERFORMANCE PROFILES");

        LinearLayout hero = card();
        TextView big = text("90% / 100%", 30, RED);
        big.setGravity(Gravity.CENTER);
        big.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        hero.addView(big);
        TextView sub = text("PREMIUM PERFORMANCE TIERS", 10, GREEN);
        sub.setGravity(Gravity.CENTER);
        hero.addView(sub);
        content.addView(hero);

        String[] plans = {
                "7 DAYS        RS.500",
                "1 MONTH       RS.1000",
                "LIFETIME       RS.2200"
        };
        for (String plan : plans) {
            LinearLayout p = card();
            p.addView(text(plan, 15, WHITE));
            Button order = action("BUY / ORDER VIA WHATSAPP", GREEN);
            p.addView(order, new LinearLayout.LayoutParams(-1,50));
            order.setOnClickListener(v -> openWhatsApp(
                    "Hello SADEE, I want to buy SADEE X DIMA OPTIMIZER.\n\n" + plan +
                    "\n\nPlease send me the payment details and activation key."));
            content.addView(p);
        }

        LinearLayout opt = rgbCard(RED);
        TextView ot = text("GAME OPTIMIZER", 15, WHITE);
        ot.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        opt.addView(ot);
        TextView os = text("CLEAR APP CACHE → PREPARE DEVICE → OPEN FREE FIRE", 9, MUTED);
        opt.addView(os);
        Button optimizer = action("🔥  OPTIMIZER SADEE X DIMA", GREEN);
        opt.addView(optimizer, new LinearLayout.LayoutParams(-1, 58));
        optimizer.setOnClickListener(v -> optimizeAndLaunchGame());
        content.addView(opt);
        rgbPulse(opt, new int[]{GREEN, RED, Color.rgb(0,220,255), Color.rgb(170,0,255)});

        TextView note = text(
                "The optimizer clears this app's own temporary cache and then tries to open Free Fire. Android does not allow a normal app to silently clear another app's private data.",
                9, MUTED);
        content.addView(note);
    }

    private void settingsPage() {
        pageHeader("SYSTEM SETTINGS", "LOCAL APP CONTROL");

        LinearLayout c = card();
        c.addView(text("APP NAME", 9, MUTED));
        c.addView(text("SADEE X DIMA OPTIMIZER", 14, WHITE));
        c.addView(text("VERSION", 9, MUTED));
        c.addView(text("V2.0 HACKER UPGRADE", 12, GREEN));
        c.addView(text("ACCESS", 9, MUTED));
        c.addView(text(premium ? "PREMIUM" : "FREE01 • 30% TIER", 12, premium ? GREEN : RED));
        content.addView(c);

        Button logout = action("⏻  LOG OUT", RED);
        content.addView(logout, new LinearLayout.LayoutParams(-1,52));
        logout.setOnClickListener(v -> {
            getSharedPreferences(PREF, MODE_PRIVATE).edit().clear().apply();
            premium = false;
            performance = 30;
            showLogin();
        });

        Button home = action("⌂  BACK TO HOME", GREEN);
        content.addView(home, new LinearLayout.LayoutParams(-1,52));
        home.setOnClickListener(v -> page(1));
    }

    private String deviceInfo() {
        return "DEVICE : " + Build.MANUFACTURER + " " + Build.MODEL +
                "\nANDROID : " + Build.VERSION.RELEASE +
                "\nAPI : " + Build.VERSION.SDK_INT +
                "\nHARDWARE : " + Build.HARDWARE +
                "\nCPU ABI : " + Build.SUPPORTED_ABIS[0];
    }

    private String batteryText() {
        android.content.IntentFilter f = new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent i = registerReceiver(null, f);
        if (i == null) return "UNKNOWN";
        int level = i.getIntExtra("level", -1);
        int scale = i.getIntExtra("scale", 100);
        if (level < 0) return "UNKNOWN";
        return Math.round(level * 100f / scale) + "%";
    }

    private void runBoost() {
        page(2);
        Toast.makeText(this, "BOOST ENGINE READY", Toast.LENGTH_SHORT).show();
    }

    private void optimizeAndLaunchGame() {
        Toast.makeText(this, "SADEE X DIMA OPTIMIZER • PREPARING...", Toast.LENGTH_SHORT).show();
        try {
            clearOwnCache();
            System.gc();
        } catch (Exception ignored) {}

        handler.postDelayed(() -> {
            String[] packages = {
                    "com.dts.freefiremax",
                    "com.dts.freefireth"
            };

            android.content.pm.PackageManager pm = getPackageManager();

            // Android 11+ requires package visibility declarations in the manifest.
            for (String pkg : packages) {
                try {
                    android.content.pm.ApplicationInfo info = pm.getApplicationInfo(pkg, 0);
                    if (!info.enabled) continue;

                    Intent launch = pm.getLaunchIntentForPackage(pkg);
                    if (launch == null) {
                        launch = new Intent(Intent.ACTION_MAIN);
                        launch.addCategory(Intent.CATEGORY_LAUNCHER);
                        launch.setPackage(pkg);
                    }

                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                    startActivity(launch);
                    Toast.makeText(this, "OPTIMIZER READY • GAME LAUNCHING", Toast.LENGTH_SHORT).show();
                    return;
                } catch (android.content.pm.PackageManager.NameNotFoundException ignored) {
                    // Try the other Free Fire edition.
                } catch (Exception ignored) {
                    // Try the other Free Fire edition.
                }
            }

            Toast.makeText(this,
                    "FREE FIRE / FREE FIRE MAX NOT FOUND",
                    Toast.LENGTH_LONG).show();
        }, 700);
    }

    private void clearOwnCache() {
        try {
            java.io.File cache = getCacheDir();
            deleteRecursive(cache);
            java.io.File ext = getExternalCacheDir();
            if (ext != null) deleteRecursive(ext);
        } catch (Exception ignored) {}
    }

    private void deleteRecursive(java.io.File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            java.io.File[] children = file.listFiles();
            if (children != null) {
                for (java.io.File child : children) deleteRecursive(child);
            }
        }
        if (!file.equals(getCacheDir())) file.delete();
    }

    private void openWhatsApp(String message) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/94768472404?text=" + Uri.encode(message)));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "WhatsApp not available", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (!loggedIn) {
            super.onBackPressed();
            return;
        }
        if (currentPage != 1) {
            page(1);
        } else {
            moveTaskToBack(true);
        }
    }
}
