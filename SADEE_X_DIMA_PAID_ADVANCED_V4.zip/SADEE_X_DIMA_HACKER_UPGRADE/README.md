# SADEE X DIMA HACKER UPGRADE V3

## Added in V3
- Animated **SADEE X DIMA SENSI** login intro.
- Green/red/RGB cyber styling.
- Large first-page device intelligence boxes using live Android values.
- Animated RGB borders around major cards.
- **OPTIMIZER SADEE X DIMA** button on the Upgrade page.
- Optimizer clears this app's own temporary cache, then tries to launch Free Fire / Free Fire MAX automatically.
- Uses the existing SADEE90 login and local session persistence.

### Important Android limitation
A normal Android app cannot silently delete another app's private data/cache. This build only clears its own temporary cache and then launches Free Fire if installed.


V4 PAID ADVANCED launch fix: added Android 11+ package visibility for Free Fire and Free Fire MAX and tries MAX first, then standard Free Fire.
