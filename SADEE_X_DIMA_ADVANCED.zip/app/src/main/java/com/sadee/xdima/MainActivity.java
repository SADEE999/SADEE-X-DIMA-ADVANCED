package com.sadee.xdima;

import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color;
import android.net.Uri; import android.os.Build; import android.view.*; import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
 LinearLayout box; TextView title, sub; boolean premium=false;
 final int CYAN=Color.rgb(0,255,204), WHITE=Color.WHITE, MUTED=Color.rgb(150,210,200);
 @Override public void onCreate(Bundle b){super.onCreate(b); showLogin();}
 TextView t(String s,int size){ TextView v=new TextView(this); v.setText(s);v.setTextColor(WHITE);v.setTextSize(size);v.setPadding(10,12,10,12);return v;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(CYAN);return b;}
 void showLogin(){
  box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);box.setPadding(28,40,28,28);box.setGravity(Gravity.CENTER);
  box.setBackgroundColor(Color.rgb(5,9,9)); setContentView(box);
  TextView h=t("SADEE X DIMA",30);h.setTextColor(CYAN);h.setGravity(17);box.addView(h);
  TextView s=t("ADVANCED OPTIMIZER\nFREE ACCESS • PREMIUM UPGRADE",14);s.setGravity(17);box.addView(s);
  EditText key=new EditText(this);key.setHint("ENTER LICENSE / FREE KEY");key.setTextColor(WHITE);key.setHintTextColor(MUTED);key.setSingleLine();box.addView(key);
  Button login=btn("LOGIN");box.addView(login);
  TextView p=t("\nFREE MODE\nFREE01 • Performance Tier 30%\n\nPremium: 90% / 100% tiers available\n",15);p.setGravity(17);box.addView(p);
  login.setOnClickListener(v->{ if("FREE01".equals(key.getText().toString().trim())){premium=false;mainUI();}else Toast.makeText(this,"Invalid key",Toast.LENGTH_SHORT).show();});
 }
 void mainUI(){
  setContentView(R.layout.activity_main); title=findViewById(R.id.title);sub=findViewById(R.id.sub);
  findViewById(R.id.b1).setOnClickListener(v->page(1));findViewById(R.id.b2).setOnClickListener(v->page(2));
  findViewById(R.id.b3).setOnClickListener(v->page(3));findViewById(R.id.b4).setOnClickListener(v->page(4));findViewById(R.id.b5).setOnClickListener(v->page(5));
  page(1);
 }
 void page(int n){
  box=findViewById(R.id.content);box.removeAllViews();
  if(n==1){box.addView(t("SYSTEM STATUS\n\n"+device()+"\n\nFREE PERFORMANCE TIER: "+(premium?"100%":"30%"),20));Button b=btn("OPTIMIZE NOW");box.addView(b);b.setOnClickListener(v->{Toast.makeText(this,"Optimization profile applied",Toast.LENGTH_SHORT).show();});}
  if(n==2){box.addView(t("BOOST CENTER\n\nBasic optimization is available in FREE mode.\nPremium unlocks advanced profiles.",20));Button u=btn("UPGRADE TO PREMIUM");box.addView(u);u.setOnClickListener(v->page(4));}
  if(n==3){box.addView(t("LIVE MONITOR\n\n"+device()+"\n\nSTATUS : "+(premium?"PREMIUM ACTIVE":"FREE ACTIVE")+"\nPROFILE : "+(premium?"ADVANCED":"BASIC"),18));}
  if(n==4){box.addView(t("PREMIUM UPGRADE\n\n90% / 100% PERFORMANCE TIERS\n\n7 DAYS  — RS.500\n1 MONTH — RS.1000\nLIFETIME — RS.2200",20));Button o=btn("ORDER VIA WHATSAPP");box.addView(o);o.setOnClickListener(v->whatsapp());}
  if(n==5){box.addView(t("SETTINGS\n\nApp: SADEE X DIMA OPTIMIZER\nMode: "+(premium?"PREMIUM":"FREE")+"\nKey: "+(premium?"Premium License":"FREE01"),18));}
 }
 String device(){return "DEVICE : "+Build.MANUFACTURER+" "+Build.MODEL+"\nANDROID : "+Build.VERSION.RELEASE+"\nCPU : "+Build.HARDWARE+"\nSDK : "+Build.VERSION.SDK_INT;}
 void whatsapp(){try{Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/94768472404?text="+Uri.encode("Hello SADEE X DIMA, I want to upgrade. Please send me the available Premium options.")));startActivity(i);}catch(Exception e){}}
}
