# SADEE X DIMA OPTIMIZER — HACKER UPGRADE V2

- FREE01 login
- Login state is saved locally so pressing Back does not return to login.
- 5 pages: Home, Boost, Monitor, Upgrade, Settings
- Green + red cyber/hacker UI
- 10-second Boost animation
- Real Android/device information
- WhatsApp upgrade flow: +94 76 847 2404
- No Supabase required for FREE01 mode
- Performance tiers: 30% free; 90%/100% premium profile labels

LOGO:
The included `app/src/main/res/drawable/sadee_logo.xml` is a temporary SADEE X DIMA cyber logo.
Replace that drawable with the user's exact logo asset when the original logo image is provided.
