# SADEE X DIMA — GitHub Actions ZIP build setup

## වැදගත්
GitHub Actions workflow එක ZIP එකක් ඇතුළේ තිබුණාට, GitHub ඒක ස්වයංක්‍රීයව හඳුනාගන්නේ නැහැ. Workflow එක repository එකේම `.github/workflows/build-from-zip.yml` path එකේ තිබිය යුතුයි.

## Setup
1. GitHub එකේ repository එකක් සාදන්න.
2. මේ ZIP එක extract කර එහි `sadee_src/` folder එකේ ඇති project files repository root එකට copy/push කරන්න **නැත්නම්** source ZIP එක repository root එකට upload කරන්න.
3. `build-from-zip.yml` file එක repository එකේ `.github/workflows/build-from-zip.yml` path එකට upload/commit කරන්න.
4. Source ZIP එක root එකේ තිබේ නම්, GitHub → Actions → “SADEE X DIMA - Extract ZIP and Build APKs” → Run workflow යන්න.
5. Build එක සාර්ථක වුණොත් workflow run එකේ Artifacts යටතේ `SADEE-X-DIMA-debug-APKs` download කරන්න.

## Limitations and safety
- මෙය **debug APK** දෙකක් build කරයි; Play Store/release distribution සඳහා signed release build එකක් නොවේ.
- Build සාර්ථක වීම app එකේ සියලු features හෝ FPS වැඩිවීම සැබෑ දුරකථනවල පරීක්ෂා කළ බව අදහස් නොවේ.
- Admin panel/security configuration එක public users හට admin controls ලබාදෙන ආකාරයට සකසා තිබිය හැක. සැබෑ customers වෙත නිකුත් කිරීමට පෙර authentication සහ Supabase Row Level Security (RLS) ප්‍රතිපත්ති නිවැරදිව සුරක්ෂිත කරන්න. Service-role/secret key එකක් APK, website හෝ GitHub repository එකට දාන්න එපා.
- Workflow එක admin website එක GitHub Pages වෙත deploy නොකරයි; APK build එකට පමණක් සීමා වේ.
